CALL OF DUTY STORE - PANEL DE ADMINISTRACIÓN
============================================

CONTENIDO
- app.py: ejemplo de aplicación Flask integrada con SQLite, pedidos y panel.
- templates/tienda.html: debes copiar aquí tu tienda.html actual.
- templates/admin.html: listado y filtros de pedidos.
- templates/login.html: inicio de sesión de administrador.
- static/admin.css: diseño militar para administración y login.
- static/estilo.css: debes copiar aquí el CSS actual de tu tienda.

INSTALACIÓN
1. Descomprime el ZIP en una carpeta.
2. Copia tu tienda.html actual a templates/tienda.html.
3. Copia tu estilo.css actual a static/estilo.css.
4. Abre una terminal en la carpeta del proyecto.
5. Instala Flask: python -m pip install flask
6. Ejecuta: python app.py
7. Abre la tienda: http://127.0.0.1:5000/
8. Abre el administrador: http://127.0.0.1:5000/admin/login

ACCESO DE PRUEBA
- Contraseña local predeterminada: jocarsa
- Cambia la contraseña antes de publicar la web. Puedes configurar ADMIN_PASSWORD
  como variable de entorno. Para despliegue real, configura también SECRET_KEY.

BASE DE DATOS
La aplicación crea tienda.db si no existe. Si la tabla productos está vacía,
introduce los 30 videojuegos de Call of Duty. Si ya tienes productos guardados,
no los reemplaza. Los pedidos nuevos se guardan en la tabla pedidos y aparecen
al entrar en el administrador.

IMPORTANTE
Este app.py es una versión integrada de ejemplo. Si ya tienes un app.py con otras
funciones, guarda una copia y combina las rutas en vez de sobrescribirlo sin revisar.
La tienda.html debe enviar el pedido mediante POST a /insertapedido con JSON.
El fondo y las fuentes externas requieren conexión a Internet.
