"""Aplicación de ejemplo para COD Store con pedidos y panel de administración.
Para producción, configura SECRET_KEY y ADMIN_PASSWORD en el entorno.
"""
import os
import json
import sqlite3
import secrets
from datetime import datetime
from decimal import Decimal, InvalidOperation
from functools import wraps
from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from werkzeug.security import check_password_hash

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, 'tienda.db')
app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY') or 'CAMBIA-ESTA-CLAVE-ANTES-DE-PUBLICAR'
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax')

COD_PRODUCTS = [
    ('Call of Duty: Black Ops 7', 'Combates futuristas y modo multijugador', '79'),
    ('Call of Duty: Black Ops 6', 'Campaña, multijugador y modo zombis', '69'),
    ('Call of Duty: Modern Warfare III', 'Acción militar y operaciones especiales', '59'),
    ('Call of Duty: Modern Warfare II', 'Combates modernos y misiones militares', '49'),
    ('Call of Duty: Modern Warfare', 'Nueva versión de la saga Modern Warfare', '39'),
    ('Call of Duty: Black Ops Cold War', 'Misiones ambientadas en la Guerra Fría', '39'),
    ('Call of Duty: Vanguard', 'Combates de la Segunda Guerra Mundial', '35'),
    ('Call of Duty: WWII', 'Batallas históricas de la Segunda Guerra Mundial', '29'),
    ('Call of Duty: Infinite Warfare', 'Combates militares en el espacio', '25'),
    ('Call of Duty: Advanced Warfare', 'Acción futurista con tecnología avanzada', '25'),
    ('Call of Duty: Ghosts', 'Historia de acción y supervivencia', '19'),
    ('Call of Duty: Black Ops III', 'Combates futuristas y modo zombis', '25'),
    ('Call of Duty: Black Ops II', 'Acción militar con diferentes decisiones', '19'),
    ('Call of Duty: Black Ops', 'Operaciones secretas durante la Guerra Fría', '19'),
    ('Call of Duty: Modern Warfare 3 (2011)', 'Continuación de la trilogía original', '15'),
    ('Call of Duty: Modern Warfare 2 (2009)', 'Combates modernos y campaña militar', '15'),
    ('Call of Duty 4: Modern Warfare', 'Juego clásico de acción militar', '15'),
    ('Call of Duty: World at War', 'Combates históricos y modo zombis', '15'),
    ('Call of Duty 3', 'Batallas de la Segunda Guerra Mundial', '12'),
    ('Call of Duty 2', 'Acción bélica en escenarios históricos', '10'),
    ('Call of Duty', 'El primer videojuego de la saga', '10'),
    ('Call of Duty: Warzone', 'Juego gratuito de tipo battle royale', '0'),
    ('Call of Duty: Mobile', 'Videojuego de acción para móviles', '0'),
    ('Call of Duty: Black Ops 4', 'Multijugador, zombis y modo Blackout', '25'),
    ('Call of Duty: Black Ops II Edición especial', 'Edición especial del juego Black Ops II', '29'),
    ('Call of Duty: Ghosts Edición especial', 'Edición especial del videojuego Ghosts', '25'),
    ('Call of Duty: Infinite Warfare Legacy Edition', 'Edición con contenido adicional', '35'),
    ('Call of Duty: WWII Edición especial', 'Edición especial de Call of Duty WWII', '39'),
    ('Call of Duty: Black Ops Cold War Ultimate Edition', 'Edición con contenido adicional', '59'),
    ('Call of Duty: Modern Warfare III Vault Edition', 'Edición con contenido extra', '99'),
]


def db():
    conexion = sqlite3.connect(DB)
    conexion.row_factory = sqlite3.Row
    return conexion


def init_db():
    with db() as c:
        c.execute('''CREATE TABLE IF NOT EXISTS productos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            descripcion TEXT,
            precio TEXT NOT NULL
        )''')
        c.execute('''CREATE TABLE IF NOT EXISTS pedidos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            numerodepedido TEXT,
            fecha TEXT,
            carga TEXT
        )''')
        c.execute('''CREATE TABLE IF NOT EXISTS pedido_estados (
            pedido_id INTEGER PRIMARY KEY,
            estado TEXT NOT NULL DEFAULT 'Pendiente'
        )''')
        if not c.execute('SELECT 1 FROM productos LIMIT 1').fetchone():
            c.executemany('INSERT INTO productos(nombre, descripcion, precio) VALUES(?,?,?)', COD_PRODUCTS)


init_db()


@app.get('/')
def home():
    return render_template('tienda.html')


@app.get('/datos')
def datos():
    with db() as c:
        productos = c.execute('SELECT * FROM productos ORDER BY id').fetchall()
    return jsonify([dict(p) for p in productos])


@app.post('/insertapedido')
def insertar_pedido():
    payload = request.get_json(silent=True)
    if not isinstance(payload, list) or not payload or len(payload) > 100:
        return jsonify(error='El pedido está vacío o no es válido.'), 400

    # El HTML de la tienda envía objetos con nombre y precio. El servidor
    # consulta el precio guardado en SQLite para no confiar en el precio del navegador.
    nombres = []
    for item in payload:
        if not isinstance(item, dict) or not item.get('nombre'):
            return jsonify(error='Producto no válido.'), 400
        nombres.append(str(item['nombre']))

    with db() as c:
        productos_db = c.execute('SELECT id, nombre, precio FROM productos').fetchall()
        por_nombre = {p['nombre']: dict(p) for p in productos_db}
        lineas = []
        for nombre in nombres:
            producto = por_nombre.get(nombre)
            if not producto:
                return jsonify(error=f'No se encontró el producto: {nombre}'), 400
            lineas.append({
                'id': producto['id'],
                'nombre': producto['nombre'],
                'precio': str(producto['precio']),
                'cantidad': 1
            })
        total = sum(Decimal(str(x['precio'])) for x in lineas)
        fecha = datetime.now().isoformat(timespec='seconds')
        cur = c.execute(
            'INSERT INTO pedidos(numerodepedido, fecha, carga) VALUES(?,?,?)',
            ('', fecha, json.dumps(lineas, ensure_ascii=False))
        )
        numero = f'PED-{datetime.now():%Y%m%d}-{cur.lastrowid:05d}'
        c.execute('UPDATE pedidos SET numerodepedido=? WHERE id=?', (numero, cur.lastrowid))
    return jsonify(ok=True, numero=numero, total=float(total)), 201


def protegido(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get('admin'):
            return redirect(url_for('login'))
        return fn(*args, **kwargs)
    return wrapper


@app.route('/admin/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        password = request.form.get('password', '')
        password_hash = os.environ.get('ADMIN_PASSWORD_HASH')
        admin_password = os.environ.get('ADMIN_PASSWORD', 'jocarsa')
        valid = (check_password_hash(password_hash, password) if password_hash
                 else secrets.compare_digest(admin_password, password))
        if valid:
            session.clear()
            session['admin'] = True
            return redirect(url_for('admin'))
        error = 'Contraseña incorrecta.'
    return render_template('login.html', error=error)


@app.post('/admin/logout')
def logout():
    session.clear()
    return redirect(url_for('home'))


@app.get('/admin')
@protegido
def admin():
    return render_template('admin.html')


@app.get('/admin/pedidos')
@protegido
def pedidos_admin():
    with db() as c:
        rows = c.execute('''SELECT p.*, COALESCE(e.estado, 'Pendiente') AS estado
            FROM pedidos p LEFT JOIN pedido_estados e ON e.pedido_id=p.id
            ORDER BY p.id DESC''').fetchall()

    salida = []
    for row in rows:
        try:
            lineas = json.loads(row['carga'] or '[]')
            if not isinstance(lineas, list):
                lineas = []
        except (ValueError, TypeError):
            lineas = []
        total = Decimal('0')
        for linea in lineas:
            if not isinstance(linea, dict):
                continue
            try:
                total += Decimal(str(linea.get('precio', 0))) * int(linea.get('cantidad', 1))
            except (InvalidOperation, ValueError, TypeError):
                continue
        salida.append({
            'id': row['id'],
            'numero': row['numerodepedido'] or f"#{row['id']}",
            'fecha': row['fecha'] or '',
            'estado': row['estado'],
            'lineas': lineas,
            'total': float(total)
        })
    return jsonify(salida)


@app.post('/admin/pedidos/<int:pedido_id>/estado')
@protegido
def cambiar_estado(pedido_id):
    estado = (request.get_json(silent=True) or {}).get('estado')
    permitidos = ['Pendiente', 'Preparando', 'Enviado', 'Entregado', 'Cancelado']
    if estado not in permitidos:
        return jsonify(error='Estado no válido.'), 400
    with db() as c:
        existe = c.execute('SELECT 1 FROM pedidos WHERE id=?', (pedido_id,)).fetchone()
        if not existe:
            return jsonify(error='Pedido no encontrado.'), 404
        c.execute('''INSERT INTO pedido_estados(pedido_id, estado) VALUES(?,?)
            ON CONFLICT(pedido_id) DO UPDATE SET estado=excluded.estado''', (pedido_id, estado))
    return jsonify(ok=True)


if __name__ == '__main__':
    app.run(debug=True)
