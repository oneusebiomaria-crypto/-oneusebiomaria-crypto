class Cliente():
  def __init__(self,minombre,misapellidos,miemail,mitelefono):
    self.nombre = minombre
    self.apellidos = misapellidos
    self.email = miemail
    self.telefono = mitelefono

class Pedido():
  def __init__(self,mifecha,micliente):
    self.fecha = mifecha
    self.cliente = Cliente()
    
cliente1 = Cliente("Eusebio María Esono","Obiang Nfiangono","oneusebimaria@gmail.com","184365789")
pedido1 = Pedido("2026-1-04",cliente1)

print(pedido1)
