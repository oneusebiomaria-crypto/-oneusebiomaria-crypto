from flask import Flask, render_template, request, jsonify
from datetime import datetime
from pathlib import Path
import sqlite3
import requests

app = Flask(__name__)
DB = Path(__file__).resolve().parent / "amable.db"
OLLAMA = "http://localhost:11434/api/generate"
MODELO = "qwen2.5-coder:3b"

def conectar():
    conexion = sqlite3.connect(DB)
    conexion.row_factory = sqlite3.Row
    return conexion

def preparar_db():
    with conectar() as db:
        db.execute("""CREATE TABLE IF NOT EXISTS webs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario TEXT, fecha TEXT, pregunta TEXT, respuesta TEXT
        )""")

@app.route("/")
def inicio():
    preparar_db()
    return render_template("principal.html")

@app.route("/procesa", methods=["POST"])
def procesa():
    datos = request.get_json(silent=True) or request.form
    peticion = (datos.get("peticion") or "").strip()
    if not peticion:
        return jsonify({"error": "Escribe qué página web quieres crear."}), 400

    sistema = """Eres un asistente especializado en crear páginas web.
Devuelve el código completo, listo para utilizar.
Usa HTML, CSS y JavaScript cuando sea necesario.
No añadas explicaciones fuera del código.
Petición del usuario:
"""
    try:
        r = requests.post(OLLAMA, json={
            "model": MODELO, "prompt": sistema + peticion, "stream": False
        }, timeout=180)
        r.raise_for_status()
        resultado = r.json().get("response", "").strip()
        if not resultado:
            return jsonify({"error": "El modelo no ha generado código."}), 502

        fecha = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with conectar() as db:
            cursor = db.execute(
                "INSERT INTO webs (usuario, fecha, pregunta, respuesta) VALUES (?, ?, ?, ?)",
                ("Eusebio Maria", fecha, peticion, resultado)
            )
            registro_id = cursor.lastrowid
        return jsonify({"id": registro_id, "pregunta": peticion,
                        "respuesta": resultado, "fecha": fecha})
    except requests.exceptions.ConnectionError:
        return jsonify({"error": "No se puede conectar con Ollama. Comprueba que esté iniciado."}), 503
    except requests.exceptions.Timeout:
        return jsonify({"error": "Ollama está tardando demasiado. Inténtalo otra vez."}), 504
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Error al consultar Ollama: {e}"}), 502
    except (ValueError, KeyError):
        return jsonify({"error": "No se ha podido leer la respuesta de Ollama."}), 502

@app.route("/historial")
def historial():
    preparar_db()
    with conectar() as db:
        filas = db.execute(
            "SELECT id, fecha, pregunta FROM webs ORDER BY id DESC LIMIT 30"
        ).fetchall()
    return jsonify([dict(f) for f in filas])

@app.route("/historial/<int:registro_id>")
def detalle_historial(registro_id):
    with conectar() as db:
        fila = db.execute(
            "SELECT id, fecha, pregunta, respuesta FROM webs WHERE id = ?",
            (registro_id,)
        ).fetchone()
    if fila is None:
        return jsonify({"error": "No se encontró esa conversación."}), 404
    return jsonify(dict(fila))

if __name__ == "__main__":
    preparar_db()
    app.run(debug=True)
