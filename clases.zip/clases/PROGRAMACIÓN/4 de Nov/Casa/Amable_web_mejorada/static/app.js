const form=document.getElementById("promptForm");
const prompt=document.getElementById("prompt");
const send=document.getElementById("send");
const counter=document.getElementById("counter");
const welcome=document.getElementById("welcome");
const result=document.getElementById("result");
const codeOutput=document.getElementById("codeOutput");
const historyList=document.getElementById("historyList");
const toast=document.getElementById("toast");
const modal=document.getElementById("modal");
const frame=document.getElementById("previewFrame");
let code="",toastTimer;

function notify(text){toast.textContent=text;toast.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>toast.classList.remove("show"),2500)}
function showCode(text){code=text;codeOutput.textContent=text;welcome.classList.add("hidden");result.classList.remove("hidden")}
function reset(){prompt.value="";counter.textContent="0 / 4000";code="";result.classList.add("hidden");welcome.classList.remove("hidden");prompt.focus()}
document.getElementById("newProject").addEventListener("click",reset);
prompt.addEventListener("input",()=>counter.textContent=`${prompt.value.length} / 4000`);
document.querySelectorAll(".idea").forEach(b=>b.addEventListener("click",()=>{prompt.value=b.dataset.prompt;counter.textContent=`${prompt.value.length} / 4000`;prompt.focus()}));

form.addEventListener("submit",async e=>{
 e.preventDefault();const peticion=prompt.value.trim();if(!peticion){notify("Escribe una petición primero.");return}
 send.disabled=true;send.textContent="Generando...";
 try{
  const r=await fetch("/procesa",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({peticion})});
  const data=await r.json();if(!r.ok)throw new Error(data.error||"No se pudo generar.");
  showCode(data.respuesta);loadHistory();notify("Código generado correctamente.");
 }catch(err){notify(err.message)}finally{send.disabled=false;send.textContent="✦ Crear página"}
});

document.getElementById("copyCode").addEventListener("click",async()=>{if(!code)return;try{await navigator.clipboard.writeText(code);notify("Código copiado.")}catch{notify("No se pudo copiar el código.")}});
document.getElementById("downloadCode").addEventListener("click",()=>{if(!code)return;const url=URL.createObjectURL(new Blob([code],{type:"text/html;charset=utf-8"}));const a=document.createElement("a");a.href=url;a.download="mi_pagina.html";a.click();URL.revokeObjectURL(url);notify("Archivo descargado.")});
document.getElementById("previewCode").addEventListener("click",()=>{if(!code)return;frame.srcdoc=code;modal.classList.remove("hidden")});
function closeModal(){modal.classList.add("hidden");frame.srcdoc=""}
document.getElementById("closeModal").addEventListener("click",closeModal);
modal.addEventListener("click",e=>{if(e.target===modal)closeModal()});
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeModal()});

async function loadHistory(){
 try{
  const r=await fetch("/historial");const items=await r.json();historyList.replaceChildren();
  if(!items.length){historyList.textContent="Todavía no hay páginas creadas.";return}
  items.forEach(item=>{const b=document.createElement("button");b.className="history-item";b.type="button";b.textContent=item.pregunta;const small=document.createElement("small");small.textContent=item.fecha;b.appendChild(small);b.addEventListener("click",()=>openHistory(item.id));historyList.appendChild(b)})
 }catch{historyList.textContent="No se pudo cargar el historial."}
}
async function openHistory(id){
 try{const r=await fetch(`/historial/${id}`);const data=await r.json();if(!r.ok)throw new Error(data.error);prompt.value=data.pregunta;counter.textContent=`${prompt.value.length} / 4000`;showCode(data.respuesta);notify("Conversación recuperada.")}catch(e){notify(e.message||"No se pudo abrir.")}
}
document.getElementById("refreshHistory").addEventListener("click",loadHistory);
prompt.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();form.requestSubmit()}});
loadHistory();
