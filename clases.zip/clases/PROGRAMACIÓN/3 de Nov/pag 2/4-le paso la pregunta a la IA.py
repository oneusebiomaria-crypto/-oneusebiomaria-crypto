# Flask permite crear webs
# render_template permite llamar a HTML
# request permite recibir información de formularios
from flask import Flask, render_template, request
import requests

aplicacion = Flask(__name__)

# Escucho en la raíz
@aplicacion.route("/")
def inicio():
    return render_template("chat.html")


@aplicacion.route("/pregunta", methods=["POST"])
def pregunta():
    # Defino la ruta donde Ollama está escuchando
    ruta = "http://localhost:11434/api/generate"

    # Elijo un modelo de entre los que he descargado
    modelo = "phi4-mini"

    # Obtengo la pregunta que viene del formulario
    texto = request.form["pregunta"]

    # Recibo la respuesta de golpe
    flujo = False

    # Hago una petición a Ollama
    r = requests.post(ruta, json={
        "model": modelo,
        "prompt": texto,
        "stream": flujo
    })

    mirespuesta = r.json()["response"]
    print(mirespuesta)

    return render_template("respuestas.html", respuesta=mirespuesta)


if __name__ == "__main__":
    aplicacion.run()
