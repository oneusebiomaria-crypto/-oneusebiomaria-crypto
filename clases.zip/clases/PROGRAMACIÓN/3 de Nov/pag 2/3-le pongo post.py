# Flask permite crear webs
# render_template permite llamar a HTML
# request permite recibir información de formularios
from flask import Flask, render_template, request

aplicacion = Flask(__name__)

# Escucho en la raíz
@aplicacion.route("/")
def inicio():
    return render_template("chat.html")


@aplicacion.route("/pregunta", methods=["POST"])
def pregunta():
    texto = request.form["pregunta"]
    print(texto)
    return render_template("respuestas.html", respuesta=texto)


if __name__ == "__main__":
    aplicacion.run()
