# Importo la librería para crear páginas web
from flask import Flask
# Importo la librería para hacer peticiones
import requests

# Creo una aplicación web
aplicacion = Flask(__name__)

# Escucho en la raíz
@aplicacion.route("/")
def inicio():
    # Defino la ruta donde Ollama está escuchando
    ruta = "http://localhost:11434/api/generate"

    # Elijo un modelo de entre los que he descargado
    modelo = "phi4-mini"

    # Establezco una pregunta
    pregunta = "Hola, ¿quién eres?"

    # Recibo la respuesta de golpe
    flujo = False

    # Hago una petición a Ollama
    r = requests.post(ruta, json={
        "model": modelo,
        "prompt": pregunta,
        "stream": flujo
    })

    # Devuelvo la respuesta
    return str(r.json()["response"])


if __name__ == "__main__":
    aplicacion.run()
