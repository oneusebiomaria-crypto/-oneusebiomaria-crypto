Vsudo mysql -u root -p

USE miweb;

SHOW TABLES;
DESCRIBE contacto;
