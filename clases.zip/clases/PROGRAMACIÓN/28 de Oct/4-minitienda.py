
# Flask permite crear webs
# render_template permite llamar a HTML
# request permite recibir información de formularios
from flask import Flask, render_template

aplicacion = Flask("__name__")

@aplicacion.route("/")
def inicio():
    return render_template("tienda.html")

@aplicacion.route("/datos")
def datos():
    return """
[
  {
    "nombre": "Call of Duty: Black Ops 7",
    "descripcion": "Combates futuristas y modo multijugador",
    "precio": "79"
  },
  {
    "nombre": "Call of Duty: Black Ops 6",
    "descripcion": "Acción, campaña y zombis",
    "precio": "69"
  },
  {
    "nombre": "Call of Duty: Modern Warfare III",
    "descripcion": "Combates modernos y operaciones especiales",
    "precio": "59"
  },
  {
    "nombre": "Call of Duty: Modern Warfare II",
    "descripcion": "Acción militar y enfrentamientos online",
    "precio": "49"
  },
  {
    "nombre": "Call of Duty: Modern Warfare",
    "descripcion": "Una nueva versión de la saga Modern Warfare",
    "precio": "39"
  },
  {
    "nombre": "Call of Duty: Black Ops Cold War",
    "descripcion": "Misiones ambientadas en la Guerra Fría",
    "precio": "39"
  },
  {
    "nombre": "Call of Duty: Vanguard",
    "descripcion": "Combates ambientados en la Segunda Guerra Mundial",
    "precio": "35"
  },
  {
    "nombre": "Call of Duty: WWII",
    "descripcion": "Historia y batallas de la Segunda Guerra Mundial",
    "precio": "29"
  },
  {
    "nombre": "Call of Duty: Infinite Warfare",
    "descripcion": "Combates militares en el espacio",
    "precio": "25"
  },
  {
    "nombre": "Call of Duty: Advanced Warfare",
    "descripcion": "Acción futurista con tecnología avanzada",
    "precio": "25"
  },
  {
    "nombre": "Call of Duty: Ghosts",
    "descripcion": "Campaña de acción y supervivencia",
    "precio": "19"
  },
  {
    "nombre": "Call of Duty: Black Ops III",
    "descripcion": "Combates futuristas y modo zombis",
    "precio": "25"
  },
  {
    "nombre": "Call of Duty: Black Ops II",
    "descripcion": "Acción militar con diferentes decisiones",
    "precio": "19"
  },
  {
    "nombre": "Call of Duty: Black Ops",
    "descripcion": "Operaciones secretas durante la Guerra Fría",
    "precio": "19"
  },
  {
    "nombre": "Call of Duty: Modern Warfare 3 (2011)",
    "descripcion": "La continuación de la trilogía original",
    "precio": "15"
  },
  {
    "nombre": "Call of Duty: Modern Warfare 2 (2009)",
    "descripcion": "Uno de los títulos clásicos de la saga",
    "precio": "15"
  },
  {
    "nombre": "Call of Duty 4: Modern Warfare",
    "descripcion": "El inicio de la famosa saga Modern Warfare",
    "precio": "15"
  },
  {
    "nombre": "Call of Duty: World at War",
    "descripcion": "Combates históricos y modo zombis clásico",
    "precio": "15"
  },
  {
    "nombre": "Call of Duty 3",
    "descripcion": "Batallas de la Segunda Guerra Mundial",
    "precio": "12"
  },
  {
    "nombre": "Call of Duty 2",
    "descripcion": "Acción bélica en escenarios históricos",
    "precio": "10"
  },
  {
    "nombre": "Call of Duty",
    "descripcion": "El primer juego de la saga",
    "precio": "10"
  },
  {
    "nombre": "Call of Duty: Warzone",
    "descripcion": "Battle royale gratuito de Call of Duty",
    "precio": "0"
  },
  {
    "nombre": "Call of Duty: Mobile",
    "descripcion": "Acción y partidas multijugador en el móvil",
    "precio": "0"
  },
  {
    "nombre": "Call of Duty: Black Ops 4",
    "descripcion": "Multijugador, zombis y Blackout",
    "precio": "25"
  },
  {
    "nombre": "Call of Duty: Black Ops II - Edición especial",
    "descripcion": "Edición especial del clásico Black Ops II",
    "precio": "29"
  },
  {
    "nombre": "Call of Duty: Ghosts - Edición especial",
    "descripcion": "Edición especial del juego Ghosts",
    "precio": "25"
  },
  {
    "nombre": "Call of Duty: Infinite Warfare - Legacy Edition",
    "descripcion": "Edición con contenido adicional de la saga",
    "precio": "35"
  },
  {
    "nombre": "Call of Duty: WWII - Edición especial",
    "descripcion": "Edición especial ambientada en la Segunda Guerra Mundial",
    "precio": "39"
  },
  {
    "nombre": "Call of Duty: Black Ops Cold War - Ultimate Edition",
    "descripcion": "Edición con contenido adicional",
    "precio": "59"
  },
  {
    "nombre": "Call of Duty: Modern Warfare III - Vault Edition",
    "descripcion": "Edición con contenido extra para el juego",
    "precio": "99"
  }
]
"""

if __name__ == "__main__":
    aplicacion.run(debug=True)

